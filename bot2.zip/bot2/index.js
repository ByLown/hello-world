const Discord = require('discord.js');

const { prefix,  token } = require('./config.json');

const client = new Discord.Client();

client.once('ready', () => {
  console.log('Ready!');
});

client.on('message', (message) => {
    if (message.content === `${prefix}ping`)  {
      message.channel.send('Pong.')
    }
    else if (message.content === `${prefix}server`) {
       message.channel.send(`Nom du serveur : ${message.guild.name};\n Nombre d'utilisateurs : ${message.guild.memberCount}`);
    }
    else if (message.content === `${prefix}avatar`) {

      if (!message.mentions.users.size) {
        return message.channel.send(`Votre avatar est : ${message.author.displayAvatarURL({ format: 'gif' })}`)
      }

      if (!message.mentions.users.size) {
        return message.channel.send(`Votre avatar est : ${message.author.displayAvatarURL({ format: 'png' })}`)
      }
      
      message.channel.send(avatarList);
    }
});

client.login(token);